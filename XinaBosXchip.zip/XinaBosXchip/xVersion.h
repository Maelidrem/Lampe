/****************************************************
 *	 This file defines the library version number	*
 ****************************************************/

#ifndef xVersion_h
#define xVersion_h

#define LIBRARY_VERSION "1.0.1"

#endif
